CREATE TABLE Tasks (
    TaskID INT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(100),
    TaskDescription TEXT,
    Status VARCHAR(20)
);